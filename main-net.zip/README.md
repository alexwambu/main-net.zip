# GBT Network Fullstack

---

## 🚀 One-Click Deploy

### ✅ Deploy Backend (Render)
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/GBTNetwork/gbt-fullstack&branch=main&source=button&file=render.yaml)

### ⚡ Deploy Frontend (Vercel)
[![Deploy to Vercel](https://vercel.com/button)](https://vercel.com/import/project?template=https://github.com/GBTNetwork/gbt-fullstack/tree/main/frontend)

### 🛠 Copy Fullstack to GitHub
[![Deploy to GitHub](https://img.shields.io/badge/GitHub-Deploy-blue?logo=github)](https://github.com/GBTNetwork/gbt-fullstack/generate)
